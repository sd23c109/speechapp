<?php
namespace MKA\Email;

class SendGridConfig {

    public static function getApiKey() {
        return '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
';
    }

    public static function getFromEmail() {
        return getenv('SENDGRID_FROM_EMAIL') ?: 'support@virtuops.com';
    }

    public static function getFromName() {
        return getenv('SENDGRID_FROM_NAME') ?: 'Speech App';
    }
}