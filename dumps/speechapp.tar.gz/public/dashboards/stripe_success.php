<?php
session_start();
require_once('/opt/mka/bootstrap.php');
require_once('/opt/mka/vendor/autoload.php');
require_once('/opt/mka/core/Payment/StripeConfig.php');

use MKA\Payment\StripeConfig;

// Get the session ID from URL
$sessionId = $_GET['session_id'] ?? null;

if (!$sessionId) {
    header('Location: /dashboards/signup.php?error=no_session');
    exit;
}

try {
    global $pdo;

    // Set Stripe API key
    \Stripe\Stripe::setApiKey(StripeConfig::getSecretKey());

    // Retrieve the checkout session
    $session = \Stripe\Checkout\Session::retrieve($sessionId);

    if (!$session) {
        throw new Exception('Invalid session');
    }

    $userUUID = $session->client_reference_id;
    $customerId = $session->customer;
    $subscriptionId = $session->subscription;

    // Retrieve the subscription to get more details
    $subscription = \Stripe\Subscription::retrieve($subscriptionId);

    // Get user type from metadata to determine tier
    $userType = $session->metadata->user_type ?? 'end_user';
    $startMode = $session->metadata->start_mode ?? 'paid';

    // Get tier_uuid based on user_type
    $stmt = $pdo->prepare("
        SELECT tier_uuid, base_price 
        FROM product_tiers 
        WHERE tier_type = ? 
        LIMIT 1
    ");
    $stmt->execute([$userType]);
    $tier = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tier) {
        throw new Exception('Product tier not found for user type: ' . $userType);
    }

    $tierUUID = $tier['tier_uuid'];
    $baseAmount = $tier['base_price'];

    // Determine subscription status
    $subStatus = ($subscription->status === 'trialing') ? 'trial' : 'active';

    // Calculate expires_at (end of current period)
    $expiresAt = date('Y-m-d H:i:s', $subscription->current_period_end);

    // Generate subscription UUID
    $subscriptionUUID = bin2hex(random_bytes(16));

    // Check if subscription already exists
    $stmt = $pdo->prepare("
        SELECT subscription_uuid 
        FROM user_subscriptions 
        WHERE user_uuid = ? AND stripe_subscription_id = ?
        LIMIT 1
    ");
    $stmt->execute([$userUUID, $subscriptionId]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        // Update existing subscription
        $stmt = $pdo->prepare("
            UPDATE user_subscriptions 
            SET stripe_customer_id = ?,
                stripe_price_id = ?,
                payment_provider = 'stripe',
                status = ?,
                expires_at = ?,
                base_amount = ?,
                final_amount = ?,
                updated_at = NOW()
            WHERE subscription_uuid = ?
        ");

        $stmt->execute([
            $customerId,
            $subscription->items->data[0]->price->id,
            $subStatus,
            $expiresAt,
            $baseAmount,
            $baseAmount, // final_amount same as base (no discount for now)
            $existing['subscription_uuid']
        ]);

    } else {
        // Insert new subscription
        $stmt = $pdo->prepare("
            INSERT INTO user_subscriptions 
            (subscription_uuid, user_uuid, tier_uuid, stripe_subscription_id, stripe_customer_id, 
             stripe_price_id, payment_provider, status, started_at, expires_at, 
             base_amount, discount_amount, final_amount, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, 'stripe', ?, NOW(), ?, ?, 0.00, ?, NOW())
        ");

        $stmt->execute([
            $subscriptionUUID,
            $userUUID,
            $tierUUID,
            $subscriptionId,
            $customerId,
            $subscription->items->data[0]->price->id,
            $subStatus,
            $expiresAt,
            $baseAmount,
            $baseAmount // final_amount same as base
        ]);
    }

    // Update user status
    $stmt = $pdo->prepare("
        UPDATE mka_users 
        SET Status = 'active'
        WHERE UserUUID = ?
    ");
    $stmt->execute([$userUUID]);

    // Log the user in
    $stmt = $pdo->prepare("SELECT * FROM mka_users WHERE UserUUID = ?");
    $stmt->execute([$userUUID]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $_SESSION['user_data'] = [
            'user_uuid' => $user['UserUUID'],
            'email' => $user['Email'],
            'name' => $user['Name'],
            'user_type' => $user['UserType'],
            'subscription_status' => $subStatus
        ];
    }

    // Set success message based on trial or paid
    if ($subStatus === 'trial') {
        $_SESSION['toast_success'] = 'Your 14-day trial has started! Welcome to Virtual Speech App.';
    } else {
        $_SESSION['toast_success'] = 'Payment successful! Welcome to Virtual Speech App.';
    }

    // Redirect to dashboard
    header('Location: /dashboards/index.php');
    exit;

} catch (Exception $e) {
    error_log("Stripe success handler error: " . $e->getMessage());
    $_SESSION['toast_error'] = 'There was an error processing your payment. Please contact support.';
    header('Location: /dashboards/signup.php');
    exit;
}